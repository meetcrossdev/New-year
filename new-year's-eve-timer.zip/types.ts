export interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isNewYear: boolean;
  nextYear: number;
}

export interface GeminiResponse {
  text: string;
}